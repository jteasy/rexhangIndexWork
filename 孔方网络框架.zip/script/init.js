//定义数据服务器地址
var serverURL = "http://www.coolfull.net/api/";
var toast_time=3000;
//定义内部版本号
var AppVersion = '8.0';
var MyAppid="A6971592675963";
var arr_wel=new Array();
arr_wel[0]='widget://image/welcome/1.jpg';
arr_wel[1]='widget://image/welcome/2.jpg';
arr_wel[2]='widget://image/welcome/3.jpg';
function start_welcome(callback)
{
	var obj=api.require('UIScrollPicture');
	obj.open(
	{
		rect:{x:0,y:0,w:api.winWidth,h:api.winHeight},
		data:{paths:arr_wel},
		placeholderImg:arr_wel[0],
		contentMode:'scaleToFill',
		interval:10000,
		auto:false,
		loop: false,
		fixedOn:'',
		fixed: true
	},
	function(ret, err)
	{
		if(ret.status)
		{
			if(ret.eventType=='click')
			{
				if(ret.index==(arr_wel.length-1))
				{
					var obj = api.require('UIScrollPicture');
					obj.close();
					if(is_define(callback))
					{
						callback();
					}
				}
			}
		}
	});
}
function show_adv(adv_img,adv_ver)
{
	set_local("adv_ver","");//正式使用的时候将这行代码屏蔽，否则每次都会弹出
	if(is_define(adv_ver)&&get_local("adv_ver")!=adv_ver)
	{
		var pageParam= new Object();
		pageParam.adv_ver=adv_ver;
		pageParam.adv_img=adv_img;
		api.openFrame(
		{
			name : 'adv',
			url : 'widget://pub_html/adv.html',
			rect : 
			{
				x : 0,
				y : 0,
				w : 'auto',
				h : 'auto'
			},
			bounces : true,
			opaque : false,
			pageParam:pageParam,
			allowEdit : true,
			bgColor : 'rgba(0,0,0,0.5)',
			vScrollBarEnabled : true,
			hScrollBarEnabled : true,
			reload : false
		});
	}
}
//打开新窗口
function open_w(name,url,pageParam)
{
	if(is_define(pageParam))
	{
		var pageParam=pageParam;
	}
	else
	{
		var pageParam=new Object();
	}
	api.openWin({
		name : name,
		url : url,
		pageParam:pageParam
	});
}
//关闭当前页面
function close_w()
{
	api.closeWin();
}
//关闭指定页面
function close_name_w(name)
{
	if (api.systemType == 'ios')
	{
		setTimeout
		(
			function()
			{
				api.execScript(
				{
					name: "root",
					script: "api.closeWin({name:'"+name+"'});"
				});
			},500
		)
	}
	else
	{
		api.closeWin({name:name});
	}
}
//打开浮动窗口
function open_f(name,url,pageParam)
{
	if(is_define(pageParam))
	{
		var pageParam=pageParam;
	}
	else
	{
		var pageParam=new Object();
	}
	var $header = $api.dom('#header');
	$api.fixIos7Bar($header);
	var $body = $api.dom('body');
	var header_h = $api.offset($header).h;
	api.openFrame(
	{
		name:name,
		url:url,
		rect:
		{
			x : 0,
			y : header_h,
			w : 'auto',
			h : 'auto'
		},
		bounces : true,
		//opaque : true,
		allowEdit : true,
		pageParam:pageParam,
		bgColor : 'rgba(0,0,0,0)',
		vScrollBarEnabled : true,
		hScrollBarEnabled : true,
		reload : false
	});
}
//打开侧滑
function open_slide() 
{
	api.openSlidPane({type : 'left'});
}
//关闭侧滑
function close_slide()
{
	api.closeSlidPane();
}

//页面关闭动作
function close_page(callback)
{
	api.addEventListener(
	{
    	name:'viewdisappear'
	},function(ret,err)
	{
		if(is_define(callback))
		{
			callback();
		}
	});
}
//页面打开动作
function open_page(callback)
{
	api.addEventListener(
	{
    	name:'viewappear'
	},function(ret,err)
	{
		if(is_define(callback))
		{
			callback();
		}
	});
}
//隐藏frame
function hide_f(name)
{
	api.setFrameAttr(
	{
		name:name,
		hidden:true,
	});
}
//关闭frame
function close_f(name)
{
	api.closeFrame(
	{
    	name:name
	});
}
function get_f_h()
{
	return api.frameHeight;
}
//页面滚动
function scroll_page(type,callback)
{
	if(type=="up")
	{
		api.pageUp
		(
			{"top":true},
		    function(ret)
		    {
		        if(is_define(callback))
		        {
		        	callback();
		        }
		    }
		);
	}
	else if(type=="down")
	{
		api.pageDown
		(
			{"bottom":true},
		    function(ret)
		    {
		        if(is_define(callback))
		        {
		        	callback();
		        }
		    }
		)
	}
}
//提示框
function $toast(txt,duration,location)
{
	if (!is_define(txt))
	{
		txt='Loading...';
	}
	if (!is_define(duration))
	{
		duration=toast_time;
	}
	if (!is_define(location))
	{
		location='middle';
	}
	api.toast({
		msg : txt,
		duration : duration,
		location : location
	});
}
//警告框
function $alert(txt,title,button)
{
	if(!is_define(title))
	{
		var title="";
	}
	if(!is_define(button))
	{
		var button="确定";
	}
	api.alert(
	{
		title : title,
		msg : txt,
		buttons:[button]
	});
}
//弹出确认
function $confirm(txt,title,button,callback)
{
	if(!is_define(title))
	{
		var title="";
	}
	if(!is_define(txt))
	{
		var txt="";
	}
	api.confirm({
		title:title,
		msg:txt,
		buttons:button
	}, function(ret, err)
	{
		if(ret.buttonIndex==1)
		{
			if(is_define(callback[0]))
			{
				callback[0]();
			}
		}
		else
		{
			if(is_define(callback[1]))
			{
				callback[1]();
			}
		}
	});
}
//弹出输入确认,type取值：text、password、number、email、url
function $prompt(txt,title,text,type,button,callback)
{
	if(!is_define(title))
	{
		var title="";
	}
	if(!is_define(txt))
	{
		var txt="";
	}
	if(!is_define(text))
	{
		var text="";
	}
	if(!is_define(type))
	{
		var type="text";
	}
	api.prompt({
		title : title,
		msg : txt,
		text : text,
		type : type,
		buttons :button
	}, function(ret, err)
	{
		if(ret.buttonIndex==1)
		{
			if(is_define(callback[0]))
			{
				callback[0](ret.text);
			}
		}
		else
		{
			if(is_define(callback[1]))
			{
				callback[1](ret.text);
			}
		}
	});
}
//底部弹出选择
function $select_sex(title)
{
	api.actionSheet(
	{
		title :title,
		cancelTitle:'关闭',
		destructiveTitle:'',
		buttons : ['男','女']
	},function(ret, err)
	{
		$alert(ret.buttonIndex);
	});
}
//时间选择安卓只支持date,time,苹果可以支持date_time
function open_datetime(title,type,date,callback)
{
	if(!is_define(title))
	{
		var title="";
	}
	if(!is_define(type))
	{
		var type="date";
	}
	if(!is_define(date))
	{
		var date="";
	}
	api.openPicker({
    type: type,
    date: date,
    title:title
	},function(ret,err)
	{
		if(is_define(callback))
		{
			if(type=="date_time")
			{
				callback(ret.year+"-"+ret.month+"-"+ret.day+"-"+ret.hour+"-"+ret.minute);
			}
			else if(type=="date")
			{
				callback(ret.year+"-"+ret.month+"-"+ret.day);
			}
			else if(type=="time")
			{
				callback(ret.hour+"-"+ret.minute);
			}
		}
	});
}
//下拉刷新
function push_down(callbak) {
	api.setRefreshHeaderInfo({
		visible : true,
		loadingImg : 'widget://image/refresh.png',
		bgColor : '#f1f1f1',
		textColor : '#4d4d4d',
		textDown : '下拉刷新...',
		textUp : '松开刷新...',
		showTime : true
	}, function(ret, err)
	{
		if (callbak)
		{
			callbak();
		}
	});
}
//下拉刷新恢复
function push_down_over()
{
	api.refreshHeaderLoadDone();
}
function push_up(callback)
{
	api.addEventListener(
	{
    	name:'scrolltobottom',
    	extra:
    	{
        	threshold:0            //设置距离底部多少距离时触发，默认值为0，数字类型
    	}
	},function(ret,err)
	{
		var html='<div id="pushup_trip" class="h15e tx-c w10 ftz10 pdt10 pdb10"><img class="w15e h15e" src="../image/loading_more.gif"></div>';
		$("#pushup_list").append(html);
		if(is_define(callback))
		{
			callback();
		}
	});
}
function push_up_over()
{
	$("#pushup_trip").remove();
}
//拨打电话
function call_tel(tel)
{
	api.call(
	{
		type : 'tel_prompt',
		number : tel
	});
}
//发送短息
function send_sms(tel,text,c1,c2)
{
	api.sms(
	{
    	numbers:[tel],
    	text:text
	},function(ret, err)
	{
	    if(ret.status)
	    {
	    	if(is_define(c1))
	    	{
	    		c1();
	    	}
	    	else
	    	{
	    		$toast('发送成功');
	    	}
	    }
	    else
	    {
	    	if(is_define(c2))
	    	{
	    		c2();
	    	}
	    	else
	    	{
	    		$toast('发送失败');
	    	}
	    }
	});
}
//设置本地存储
function set_local(key,val)
{
	$api.setStorage(key,val);
	//set_local(key, val);
}
//获取本地存储
function get_local(key)
{
	return $api.getStorage(key);
	//return get_local(key);
}
//加载网页
function load_link(url)
{
	if (api.systemType == 'ios')
	{
		api.openApp({
			iosUrl : url,

		},function(ret, err)
		{
		});
	}
	else
	{
		api.openApp(
		{
			androidPkg : 'android.intent.action.VIEW',
			mimeType : 'text/html',
			uri : url
		},function(ret, err)
		{
		});
	}
}
//json转字符串
function json2str(j)
{
	return JSON.stringify(j);
}
//字符串转json
function str2json(s)
{
	return JSON.parse(s);
}
//判断字符串是否在array中
function in_array(stringToSearch, arrayToSearch)
{
 	for(s=0;s<arrayToSearch.length;s++)
	{
  		thisEntry = arrayToSearch[s].toString();
  		if(thisEntry == stringToSearch)
		{
   			return true;
  		}
 	}
 	return false;
}
//获得设备编号
function get_deviceId()
{
	var deviceId = api.deviceId;
	deviceId = deviceId.replace(/\-/g, "");
	return deviceId;
}
//显示模态加载
function show_doing(title,text)
{
	if(!is_define(title))
	{
		var title='';
	}
	if(!is_define(text))
	{
		var text='';
	}
	api.showProgress(
	{
	    style: 'default',
	    animationType: 'fade',
	    title:title,
	    text:text
	});
}
//关闭模态加载
function hide_doing()
{
	api.hideProgress();
}
/*
 *Loading
 */
function loading(time) {
	var str = "";
	str += '<div id="zv_Loading"></div><div id="zv_main"></div><div id="Loadbox">';
	str += '<div class="LoadBoxList">';
	str += '<div id="loadbg"><img src="../image/nobg.png" style="width:5em; height:5em"></div>';
	str += '<div id="loadingimgbox"><img src="../image/logo.png" id="loadingimg"></div>';
	str += '<div id="loadingimgboxtxt">加载中...</div>';
	str += '</div>';
	str += '</div>';
	var d = document.createElement('DIV');
	d.innerHTML = str;
	document.body.appendChild(d);
	if (parseInt(time) < 0) {
		document.getElementById("zv_main").style.display = "none";
		document.getElementById("Loadbox").style.display = "none";
		fadeEffect.init('fadeIn', 1)
	}
	if (parseInt(time) == 0) {
		document.getElementById("zv_main").style.display = "block";
		document.getElementById("Loadbox").style.display = "block";
	}
	if (parseInt(time) > 0) {
		document.getElementById("zv_main").style.display = "block";
		document.getElementById("Loadbox").style.display = "block";
		setTimeout(function()
		{
			$api.css($api.byId("content"),"display:block");
			document.getElementById("zv_main").style.display = "none";
			document.getElementById("Loadbox").style.display = "none";
			fadeEffect.init('fadeIn', 20)
		},time);
	}
}
function check_update()
{
	var mam = api.require('mam');
	mam.checkUpdate(function(ret, err)
	{
    	if (ret) 
    	{
        	var result = ret.result;
        	if(ret.status==1)
        	{
        		if(result.update)
        		{
        			api.confirm(
					{
						title:'版本更新',
						msg : '发现新版本：'+result.version+','+result.updateTip,
						buttons : ['确定更新', '稍后再说']
					},
					function(ret, err)
					{
						if (ret.buttonIndex==1)
						{
							if (api.systemType=='ios') 
							{
								api.installApp(
								{
								    appUri:result.source       //安装包对应plist地址
								});
								exit_app();
							}
							else
							{
								location.href=result.source;
							}
						}
					})
        		}
        		else
        		{
        			$toast('暂无新版本','1000');
        		}
        	}
        	else
        	{
        		$toast('暂无新版本','1000');
        	}
    	}
    	else
    	{
        	api.alert({msg:err.msg});
    	};
	});
}
//静默更新
function update_widget()
{
	api.addEventListener({
	    name:'smartupdatefinish'
    },
    function(ret,err)
    {
    	if(is_define(ret.value[0].extra))
		{
			$confirm(ret.value[0].extra,'请重启应用','',new Array('',exit_app));
		}
    });
}
function exit_app()
{
	api.closeWidget(
	{
	    id: MyAppid,
	    retData: {name:'closeWidget'},
	    animation: 
	    {
	        type: 'flip',
	        subType: 'from_bottom',
	        duration: 500
	    },
	    silent:true
	});
}
//退出App
function android_exit()
{
	api.addEventListener(
	{
		name:'keyback'
	},
	function(ret,err)
	{
		api.toast(
		{
			msg : '再按一次返回键退出'+api.appName,
			duration : 2000,
			location : 'bottom'
		});
		api.addEventListener(
		{
			name:'keyback'
		},
		function(ret, err)
		{
			exit_app();
		});
	});
}
//执行指定窗口界面
function ue_script(winname,fun)
{
	api.execScript(
	{
		name:winname,
		script:fun
	});
}
//执行指定窗口界面
function ue_script_f(winname,framename,fun)
{
	api.execScript(
	{
		name:winname,
		frameName:framename,
		script:fun
	});
}
/**
 * 判断是否是空
 * @param value
 */
function is_define(value)
{
	if (value == null || value == "" || value == "undefined" || value == undefined || value == "null" || value == "(null)" || value == 'NULL' || typeof (value) == 'undefined')
	{
		return false;
	}
	else
	{
		value = value + "";
		value = value.replace(/\s/g, "");
		if (value == "")
		{
			return false;
		}
		return true;
	}
}
//清楚缓存
function clear_cache(callback)
{
	$toast('已清除',1000);
	if(is_define(callback))
	{
		callback();
	}
}
//网络不好的情况
function net_error(callback)
{
	$toast('网络开小差',1000);
	if(is_define(callback))
	{
		callback();
	}
}
//页面轻滑
function swipe(name,callback)
{
	api.addEventListener(
	{
		name:name
	},
	function(ret,err)
	{
		if(is_define(callback))
		{
			callback();
		}
	})
}
function select_img(callback)
{
	if(!is_define(callback))
	{
		var callback='';
	}
	api.actionSheet(
	{
		title : '上传头像',
		cancelTitle : '关闭',
		buttons : ['打开相机', '本地图库']
	}, function(ret, err)
	{
		if(ret.buttonIndex==3)
		{
			return false;
		}
		else
		{
			var type_arr=new Array('camera','library');
			api.getPicture(
			{
				sourceType : type_arr[ret.buttonIndex-1],
				encodingType : 'jpg',
				mediaValue : 'pic',
				destinationType : 'url',
				allowEdit : true,
				quality : 50,
				targetWidth : 300,
				targetHeight : 300,
				saveToPhotoAlbum : false
			},function(ret, err)
			{
				if (ret)
				{
					if(is_define(callback))
					{
						callback(ret.data);
					}
				}
			})
		}
	});
}
function get_par()
{
	return api.pageParam;
}
function download(url,callback,filename,savedir)
{
	if(!is_define(filename))
	{
		var file_arr=url.split(".");
		var file_arr_len=file_arr.length;
		var ext_name=file_arr[file_arr_len-1];//得到扩展名
		var filename=new Date().getTime()+"."+ext_name;
	}
	if(!is_define(savedir))
	{
		var savedir="down/";
	}
	var savepath='widget://'+savedir+'/'+filename+'';
	api.download(
	{
	    url: url,
	    savePath: savepath,
	    report: true,
	    cache: true,
	    allowResume:true
	},function(ret,err)
	{
	    if (ret.state==1)
	    {
	        if(is_define(callback))
	        {
	        	callback(ret.savePath);
	        }
	    }
	});
}
function get_os(callback)
{
	var os=api.systemType;
	if(is_define(callback))
	{
		callback(os);
	}
	else
	{
		return os;
	}
}
//控制只能输入小数
function input_float(v)
{
    for(var i = v.value.length; i > 0; i--)
    {
        if(!/^\d*(\.\d*)?$/.test(v.value[i]))
        if(!/^\d*\.?\d{0,2}$/.test(v.value))//只能输入两位小数
        {
            v.value=v.value.substr(0,v.value.length-1);
        }
    }
}
//控制只能输入整数
function input_int(v)
{
    v.value= v.value.replace(/[^\d]/g,'');
}
//是否手机号码
function is_mobile(v)
{
	var reg=/^1[3|4|5|7|8|][0-9]{9}$/;
	if(reg.exec(v))
	{
		return true;
	}
	else
	{
		return false;
	}
}